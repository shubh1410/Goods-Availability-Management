import requests

url = "https://api.github.com/repos/shubh1410/godam-warehouse-inventory-management-/releases"
data = requests.get(url).json()

dwnldCount = 0;
for i in range(len(data)):
	try:
		dwnldCount = dwnldCount + data[i]['assets'][0]['download_count']
	except IndexError as e:
		pass
print("The total no of downloads till now for all release is",dwnldCount)
