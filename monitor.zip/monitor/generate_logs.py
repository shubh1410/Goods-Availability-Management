import requests
import csv
import pandas as pd
import json
import time
from datetime import datetime


url = "https://api.github.com/repos/shubh1410/Goods-Availability-Management/releases"
data = requests.get(url).json()
data1=[]
dwnldCount = 0;
for i in range(len(data)):
	try:
		dwnldCount = dwnldCount + data[i]['assets'][0]['download_count']
		data1.append([data[i]['created_at'][0:10],data[i]['tag_name'],data[i]['assets'][0]['download_count']])
		#print(data[i]['created_at']),
		#print(data[i]['tag_name']),
		#print(data[i]['assets'][0]['download_count'])
	except IndexError as e:
		pass
df = pd.DataFrame(data1, columns = ['timestamp','tag_name','count'])
df.to_csv('/var/lib/jenkins/jobs/monitor/builds/monitor/a1.csv',index=False)
#print("The total no of downloads till now for all release is",dwnldCount)

with open('/var/lib/jenkins/jobs/monitor/builds/monitor/account_file.json', 'r') as myfile:
    data_user=myfile.read()


obj = json.loads(data_user)
user_list=[]
dwnldCount = 0;
for i in range(len(obj['users'])):
	try:


		#print(time1)
		user_list.append([time.strftime('%Y-%m-%d', time.localtime(float(obj['users'][i]['createdAt'])/1000)),obj['users'][i]['emailVerified'],time.strftime('%Y-%m-%d', time.localtime(float(obj['users'][i]['lastSignedInAt'])/1000)),obj['users'][i]['email']])
		#print(data[i]['created_at']),
		#print(data[i]['tag_name']),
		#print(data[i]['assets'][0]['download_count'])

	except IndexError as e:
		pass

df = pd.DataFrame(user_list, columns = ['timestamp','emailVerified','lastSignedInAt','email'])
df.to_csv('/var/lib/jenkins/jobs/monitor/builds/monitor/users1.csv',index=False)
